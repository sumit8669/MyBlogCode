package com.sumit.blog;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sumit.blog.repository.UserRepo;

@SpringBootTest
class BlogAppApplicationTests {
	
	@Autowired
	private UserRepo repo;

	@Test
	void contextLoads() {
	String name = this.repo.getClass().getName();
	String pack = this.repo.getClass().getPackageName();
	
	System.out.println(name);
	System.out.print(pack);
	
	}

}
