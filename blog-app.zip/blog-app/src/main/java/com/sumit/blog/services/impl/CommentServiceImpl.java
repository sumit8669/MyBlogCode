package com.sumit.blog.services.impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sumit.blog.exceptions.ResourceNotFoundException;
import com.sumit.blog.models.Comment;
import com.sumit.blog.models.Post;
import com.sumit.blog.payloads.CommentDto;
import com.sumit.blog.repository.CommentRepo;
import com.sumit.blog.repository.PostRepo;
import com.sumit.blog.services.CommentService;

@Service
public class CommentServiceImpl implements CommentService {

	 @Autowired
	 private CommentRepo commentRepo;
	 
	 @Autowired
	 private PostRepo postRepo;
	
	 @Autowired
	 private ModelMapper mapper;
	 
	 
	@Override
	public CommentDto createComment(CommentDto commentDto, Integer postId) {
			Post post = this.postRepo.findById(postId)
							.orElseThrow(() -> new ResourceNotFoundException("post", "postId", postId));
		
			 Comment comment = this.mapper.map(commentDto, Comment.class);
			 comment.setPost(post);
			 
			 Comment saveComment = this.commentRepo.save(comment);
			
			return this.mapper.map(saveComment, CommentDto.class);
	}

	@Override
	public void deleteComment(Integer commentId) {
		Comment com = this.commentRepo.findById(commentId)
						.orElseThrow(() -> new ResourceNotFoundException("comment","commentId",commentId));
		
		this.commentRepo.delete(com);
	}

}
